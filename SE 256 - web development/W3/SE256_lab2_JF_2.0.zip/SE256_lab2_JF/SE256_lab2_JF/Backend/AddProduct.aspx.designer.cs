﻿namespace SE256_lab2_JF.Backend
{
    public partial class AddProduct
    {
        protected global::System.Web.UI.WebControls.Label product_id;
        protected global::System.Web.UI.WebControls.TextBox name;
        protected global::System.Web.UI.WebControls.TextBox manufacturer;
        protected global::System.Web.UI.WebControls.Calendar date_Expires;
        protected global::System.Web.UI.WebControls.TextBox price;
        protected global::System.Web.UI.WebControls.Button submit_button;
        protected global::System.Web.UI.WebControls.Label feedback_label;
    }
}

